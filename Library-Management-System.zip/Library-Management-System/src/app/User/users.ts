export class Users {
    id: string;
    Title: string;
    Author: string;
    Subject: string;
    Rack_No: string;

    constructor(id, Title, Author, Subject, Rank_No, YearofPublication) {
        this.id = id;
        this.Title = Title;
        this.Author = Author;
        this.Subject = Subject;
        this.Rack_No = this.Rack_No;


    }
}
